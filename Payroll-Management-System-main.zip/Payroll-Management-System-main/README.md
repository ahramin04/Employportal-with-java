# Payroll-Management-System
A Payroll Management System (PMS) done as a DBMS Lab project

# Abstract 
Payroll Management System (PMS) is a robust database solution for startups and established
companies to manage their payroll. It allows for automatic salary calculation and management,
supports tax management and effective record keeping. It would also keep track of paid and unpaid
leaves and store employee data for easy access

# Team Members
* Aadithya Sai G Menon
* Akshara Vijay
* Alen Thomas
* Alka Antony
* Archana Rajendran
