// const getStuff = async () => {
//   return axios.get("http://localhost:8000/").then((response) => response.data);
// };

// getStuff();

// async function displayStuff() {
//   const testPara = document.getElementById("test-para");
//   const stuff = document.createTextNode(JSON.stringify(await getStuff()));

//   testPara.appendChild(stuff);
// }

// window.onload = displayStuff();
